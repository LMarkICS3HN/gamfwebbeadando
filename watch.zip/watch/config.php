<?php
$menuItems = array(
    'Favorites' => 'kedvencek',
    'Series' => 'series',
    'Movies' => 'movies',
    'Contact Us!' => 'contact_form'
);
?>